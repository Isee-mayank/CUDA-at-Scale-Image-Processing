
# CUDA at Scale - Batch Image Processing

## Project Overview
This project demonstrates GPU-accelerated image processing
using NVIDIA CUDA and CuPy on a Tesla T4 GPU.

## Image Processing Operations
1. Grayscale conversion
2. Sobel edge detection

## Dataset
100 generated sample images were processed in batch.
A cat photograph was also used to demonstrate the visual
difference between original, grayscale, and edge-detected images.

## GPU
NVIDIA Tesla T4

## Technologies
- Python
- CUDA
- CuPy
- NumPy
- Pillow
- Google Colab

## Project Folders
- input_images/: Generated input dataset
- output_images/: Grayscale results
- edge_outputs/: Sobel edge detection results
- cat_input/: Uploaded cat photograph
- cat_outputs/: Cat processing results and comparison image

## Execution Results
The initial batch grayscale run processed 100 images.
The measured total elapsed time was 0.8096 seconds,
including image loading, data transfers, processing, and saving.

## Note
Execution times may vary between runs and GPU sessions.
